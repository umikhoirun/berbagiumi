library(testthat)
library(fingertipsR)

test_check("fingertipsR", filter = "^[a-c]")
